import '../models/BMCommonCardModel.dart';
import 'BMDataGenerator.dart';

const appName = 'Beauty Master';

List<BMCommonCardModel> favList = getFavList();
const isDarkModeOnPref = 'isDarkModeOnPref';
